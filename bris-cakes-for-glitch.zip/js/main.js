document.addEventListener('DOMContentLoaded', function() {
  // Mobile navigation toggle
  const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
  const navLinks = document.querySelector('.nav-links');
  
  if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener('click', function() {
      navLinks.classList.toggle('active');
    });
  }
  
  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href');
      const targetElement = document.querySelector(targetId);
      
      if (targetElement) {
        // Close mobile menu if open
        if (navLinks.classList.contains('active')) {
          navLinks.classList.remove('active');
        }
        
        window.scrollTo({
          top: targetElement.offsetTop - 80, // Account for fixed header
          behavior: 'smooth'
        });
      }
    });
  });
  
  // FAQ accordion functionality
  const faqQuestions = document.querySelectorAll('.faq-question');
  
  faqQuestions.forEach(question => {
    question.addEventListener('click', function() {
      const answer = this.nextElementSibling;
      const isActive = answer.classList.contains('active');
      
      // Close all answers
      document.querySelectorAll('.faq-answer').forEach(item => {
        item.classList.remove('active');
      });
      
      // Toggle the current answer
      if (!isActive) {
        answer.classList.add('active');
      }
    });
  });
  
  // Image upload preview
  const fileInput = document.getElementById('inspiration-photo');
  const imagePreview = document.getElementById('image-preview');
  let base64Image = '';
  
  if (fileInput) {
    fileInput.addEventListener('change', function() {
      const file = this.files[0];
      
      if (file) {
        const reader = new FileReader();
        
        reader.addEventListener('load', function() {
          imagePreview.src = this.result;
          imagePreview.style.display = 'block';
          base64Image = this.result;
        });
        
        reader.readAsDataURL(file);
      }
    });
  }
  
  // Form validation functions
  function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  }
  
  function validatePhone(phone) {
    const re = /^\d{10}$/;
    return re.test(String(phone).replace(/[^\d]/g, ''));
  }
  
  function showFormError(message) {
    const errorDiv = document.getElementById('form-error');
    if (errorDiv) {
      errorDiv.textContent = message;
      errorDiv.style.display = 'block';
    } else {
      // Create error element if it doesn't exist
      const newErrorDiv = document.createElement('div');
      newErrorDiv.id = 'form-error';
      newErrorDiv.className = 'form-error';
      newErrorDiv.textContent = message;
      
      const formContainer = document.querySelector('#order-form');
      formContainer.parentNode.insertBefore(newErrorDiv, formContainer);
    }
  }
  
  function hideFormError() {
    const errorDiv = document.getElementById('form-error');
    if (errorDiv) {
      errorDiv.style.display = 'none';
    }
  }
  
  function showFormSuccess(message) {
    const successDiv = document.getElementById('form-success');
    if (successDiv) {
      successDiv.textContent = message;
      successDiv.style.display = 'block';
    } else {
      // Create success element if it doesn't exist
      const newSuccessDiv = document.createElement('div');
      newSuccessDiv.id = 'form-success';
      newSuccessDiv.className = 'form-success';
      newSuccessDiv.textContent = message;
      
      const formContainer = document.querySelector('#order-form');
      formContainer.parentNode.insertBefore(newSuccessDiv, formContainer);
    }
    
    // Hide success message after 5 seconds
    setTimeout(() => {
      const successDiv = document.getElementById('form-success');
      if (successDiv) {
        successDiv.style.display = 'none';
      }
    }, 5000);
  }
  
  // Form submission
  const orderForm = document.getElementById('order-form');
  
  if (orderForm) {
    orderForm.addEventListener('submit', function(e) {
      e.preventDefault();
      hideFormError();
      
      // Basic validation
      const email = document.getElementById('email').value;
      const phone = document.getElementById('phone').value;
      
      if (!validateEmail(email)) {
        showFormError('Please enter a valid email address');
        return;
      }
      
      if (!validatePhone(phone)) {
        showFormError('Please enter a valid 10-digit phone number');
        return;
      }
      
      // Show loading state
      const submitButton = this.querySelector('button[type="submit"]');
      const originalButtonText = submitButton.textContent;
      submitButton.textContent = 'Sending...';
      submitButton.disabled = true;
      
      // Collect form data
      const formData = new FormData(this);
      const orderData = {};
      
      formData.forEach((value, key) => {
        // Skip file input, we'll handle it separately
        if (key !== 'inspirationPhoto') {
          orderData[key] = value;
        }
      });
      
      // Add base64 image if exists
      if (base64Image) {
        orderData.inspirationPhotoBase64 = base64Image;
      }
      
      // Determine if we're running on a server or just a static file
      const isServerEnvironment = window.location.hostname !== '' && 
                               window.location.hostname !== 'localhost' && 
                               window.location.hostname !== '127.0.0.1';
      
      if (isServerEnvironment) {
        // Use actual server API
        fetch('/api/submit-order', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(orderData)
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            showFormSuccess(data.message);
            
            // Reset the form
            orderForm.reset();
            imagePreview.style.display = 'none';
            base64Image = '';
          } else {
            showFormError(data.message || 'There was an error submitting your order. Please try again.');
          }
        })
        .catch(error => {
          showFormError('There was an error submitting your order. Please try again later.');
          console.error('Error:', error);
        })
        .finally(() => {
          // Reset button
          submitButton.textContent = originalButtonText;
          submitButton.disabled = false;
        });
      } else {
        // Simulate server response for local testing
        setTimeout(() => {
          console.log('Order data:', orderData);
          
          // Simulate successful submission
          showFormSuccess('Thank you for your order! We will contact you soon to confirm the details.');
          
          // Reset the form
          orderForm.reset();
          imagePreview.style.display = 'none';
          base64Image = '';
          
          // Reset button
          submitButton.textContent = originalButtonText;
          submitButton.disabled = false;
        }, 1500);
      }
    });
  }
});