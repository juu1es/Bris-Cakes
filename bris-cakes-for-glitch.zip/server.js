// Simple Express server to serve the static website
const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files
app.use(express.static(path.join(__dirname)));

// Handle form submissions
app.use(express.json({limit: '50mb'}));
app.use(express.urlencoded({extended: true, limit: '50mb'}));

app.post('/api/submit-order', (req, res) => {
  // In a real application, you would:
  // 1. Validate the data
  // 2. Store the order in a database
  // 3. Send notification emails
  // 4. Process payments, etc.
  
  console.log('New order received:', req.body);
  
  // For demo purposes, just send back a success response
  res.json({
    success: true,
    message: 'Order received successfully! We will contact you soon to confirm details.'
  });
});

// Handle all routes - serve index.html for any request
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Start the server - this works well with Glitch
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});