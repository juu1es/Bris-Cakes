# Bri's Cakes - Glitch Instructions

## How to Import this Project to Glitch

### Option 1: Import via GitHub
1. Create a GitHub repository with these files
2. Go to [Glitch.com](https://glitch.com/)
3. Click "New Project" > "Import from GitHub"
4. Enter your repository URL

### Option 2: Import from .zip file
1. Download all files as a .zip
2. Go to [Glitch.com](https://glitch.com/)
3. Click "New Project" > "Hello-Webpage"
4. Once your project opens, click "Tools" in the bottom left
5. Select "Import / Export" from the menu
6. Click "Import from your computer" and select your .zip file

### Option 3: Upload files directly
1. Go to [Glitch.com](https://glitch.com/)
2. Click "New Project" > "Hello-Webpage"
3. Once in your new project, delete any default files
4. Click on "assets" in the left sidebar
5. Drag and drop all your project files here
6. Click on "package.json" to edit it to match the one from this project

## Running on Glitch

1. Glitch will automatically detect the Express server in `server.js`
2. Your app will be live at `https://your-project-name.glitch.me`
3. The form submissions will work properly right away

## Customizing on Glitch

- Edit files directly in the Glitch editor
- All changes save automatically
- Your app automatically restarts when you make changes

## Files to Check First

1. `index.html` - Main content
2. `css/styles.css` - Styling 
3. `js/main.js` - Functionality

## Troubleshooting

If your app doesn't start properly on Glitch:

1. Check the Glitch logs by clicking on "Logs" at the bottom of the screen
2. Make sure `package.json` was imported correctly
3. Try running `refresh` in the Console

Remember that Glitch projects go to sleep after a period of inactivity. They'll wake up automatically when someone visits your site.