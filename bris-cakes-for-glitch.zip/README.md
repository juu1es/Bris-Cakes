# Bri's Cakes Website

A simple, responsive website for Bri's Cakes, a custom cake business specializing in decorated cakes for all occasions.

## Features

- Responsive design that works on mobile, tablet, and desktop
- Cake flavors and pricing information
- About section with business details
- How to order process explanation
- FAQ section
- Order form with image upload capability
- Mobile-friendly navigation

## Getting Started

There are two ways to run this website:

### Method 1: Simple Static Version

1. Simply open the `index.html` file in any web browser.
2. The website will work, but the form submissions will not be processed by a server.

### Method 2: With Local Server (Recommended)

1. Make sure you have [Node.js](https://nodejs.org/) installed.
2. Open a terminal/command prompt in the project directory.
3. Install dependencies:
   ```
   npm install
   ```
4. Start the server:
   ```
   npm start
   ```
5. Open your browser and go to [http://localhost:3000](http://localhost:3000)

## Development

For development with auto-restart when files change:

```
npm run dev
```

## Project Structure

- `index.html` - The main HTML file
- `css/styles.css` - All styles for the website
- `js/main.js` - JavaScript functionality
- `images/` - All image assets
- `server.js` - Simple Express server for form processing

## Customization

- Colors: Edit the CSS variables in `css/styles.css` to change the color scheme
- Content: Update the text in `index.html`
- Images: Replace images in the `images` folder
- Functionality: Modify `js/main.js` to change interactive features

## Technical Notes

- This website uses vanilla JavaScript without any frameworks
- For form submissions, data is logged to the console in the static version
- In the server version, form submissions are handled by Express
- Image uploads are handled as base64 data